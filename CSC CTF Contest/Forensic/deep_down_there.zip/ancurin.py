from secrets import key

assert len(key) <= 8

with open('flag.png', 'rb') as f:
	flag = f.read()

enkripsi = b''
for i in range(len(flag)):
    enkripsi += (flag[i] ^ key[i % len(key)]).to_bytes(1, 'big')
	    
with open('ancur.png', 'wb') as ancur:
	ancur.write(enkripsi)


