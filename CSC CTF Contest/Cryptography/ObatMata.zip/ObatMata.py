from Crypto.Util.number import *
from sympy import *

flag = b'REDACTED'

BITS = 2048
p = getPrime(BITS)
q = nextprime(p)
while (p%4 != 3 or q%4 !=3):
	p = getPrime(BITS)
	q = nextprime(p)

n = p*q

enkripsi = pow(bytes_to_long(flag),BITS,n) % n

print(f'n = {n}')
print(f'enkripsi = {enkripsi}')